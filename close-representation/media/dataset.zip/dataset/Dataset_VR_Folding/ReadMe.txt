The VR Folding Dataset can be downloaded from: https://huggingface.co/datasets/robotflow/vr-folding

We provide csv files that contain the framenumber of the start and the end manipulation sequences. We also share the depth masks we used in our evaluations.
